import Logo from "../../../../public/Slicing/header/logo.png"
const NaveLeft = () => {
  return (
    <div className=" lg:visible lg:flex lg:items-center">
      <img src={Logo} alt="" className="w-[19vw] lg:w-full " />
    </div>
  )
}

export default NaveLeft