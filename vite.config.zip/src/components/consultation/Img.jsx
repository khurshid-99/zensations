const Img = () => {
  return (
    <div className="w-full px-[5vw] lg:px-0 lg:w-1/3 ">
      <img
        src="Slicing/header/about-image.jpg"
        alt=""
        className="w-full h-full object-cover object-center"
      />
    </div>
  );
};

export default Img;
